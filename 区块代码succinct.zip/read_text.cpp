#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdint>

using namespace std;

// 结构体定义
struct ReferenceData {
    uint16_t Rfr_angle;
    uint32_t Rfr_dist_mm;
};

int main() {
    // 打开文档
    ifstream infile("data.txt");
    if (!infile) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    // 存储数据的向量
    vector<ReferenceData> Reference_Array;

    string line;
    while (getline(infile, line)) {
        if (line.empty())
            continue;

        // 解析每行数据
        ReferenceData data;
        stringstream ss(line);

        // 读取和解析数据
        string temp;
        ss >> temp >> data.Rfr_angle >> temp >> temp >> data.Rfr_dist_mm >> temp;

        // 将数据存入数组
        Reference_Array.push_back(data);
    }

    // 输出数组中的数据
    cout << "Printing Reference_Array:" << endl;
    for (size_t i = 0; i < Reference_Array.size(); ++i) {
        cout << "Reference_Array[" << i << "].Rfr_angle = " << Reference_Array[i].Rfr_angle << "; ";
        cout << "Reference_Array[" << i << "].Rfr_dist_mm = " << Reference_Array[i].Rfr_dist_mm << endl;
    }

    return 0;
}
