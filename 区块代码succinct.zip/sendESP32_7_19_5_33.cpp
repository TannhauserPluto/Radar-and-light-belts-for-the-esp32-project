#include <iostream>   // 标准输入输出流
#include <fstream>    // 文件流，不一定需要，这里未使用
#include <string>     // 字符串处理
#include <Windows.h>  // Windows特定的API，用于串口通信

void sendDataToESP32(const std::string& data)
{
    // 打开串口
    HANDLE hSerial = CreateFile(L"COM6", GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (hSerial == INVALID_HANDLE_VALUE)
    {
        // 处理串口打开失败的情况
        if (GetLastError() == ERROR_FILE_NOT_FOUND)
        {
            std::cerr << "Serial port not available." << std::endl;
        }
        else
        {
            std::cerr << "Error opening serial port." << std::endl;
        }
        return;
    }

    // 配置串口参数
    //用于设置串口的参数，包括波特率（BaudRate）、数据位（ByteSize）、停止位（StopBits）和校验位（Parity）
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    if (!GetCommState(hSerial, &dcbSerialParams))
    {
        std::cerr << "Error getting serial port state." << std::endl;
        CloseHandle(hSerial);
        return;
    }

    dcbSerialParams.BaudRate = CBR_115200;  // 设置波特率，根据ESP32的设置来调整
    dcbSerialParams.ByteSize = 8;           // 数据位
    dcbSerialParams.StopBits = ONESTOPBIT;  // 停止位
    dcbSerialParams.Parity = NOPARITY;      // 校验位

    if (!SetCommState(hSerial, &dcbSerialParams))
    {
        std::cerr << "Error setting serial port state." << std::endl;
        CloseHandle(hSerial);
        return;
    }

    // 发送数据
    DWORD bytesWritten;
    if (!WriteFile(hSerial, data.c_str(), data.length(), &bytesWritten, 0))
    {
        std::cerr << "Error writing to serial port." << std::endl;
    }
    else
    {
        std::cout << "Sent data to ESP32: " << data << std::endl;
    }

    // 关闭串口
    CloseHandle(hSerial);
}
int main()
{
    std::string message = "Hello ESP32!";
    sendDataToESP32(message);

    return 0;
}

