
/*完成雷达任务 简约版 准备加入于master通信*/

// ultra_simple
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

// find varaition data
#include <iostream>
#include <vector>
#include <cstdint>

// calculate coordinate
//#include <iostream>
#include <cmath>
//#include <vector>
#ifndef M_PI
#define M_PI 3.142
#endif

//send data to esp32(master)
//#include <iostream>   
//#include <fstream>    // 文件流，不一定需要，这里未使用
//#include <string>     // 字符串处理
#include <Windows.h>  // Windows特定的API，用于串口通信

// wait
// #include <iostream>
#include <thread>
#include <chrono>

// ultra_simple
#include "sl_lidar.h" 
#include "sl_lidar_driver.h"
#ifndef _countof// 如果定义了_countof（计算数组大小）
#define _countof(_Array) (int)(sizeof(_Array) / sizeof(_Array[0]))// 用于计算数组大小
#endif

#ifdef _WIN32// 用于处理跨平台
#include <Windows.h>
#define delay(x)   ::Sleep(x)// 32的delay代码不同
#else
#include <unistd.h>
static inline void delay(sl_word_size_t ms)
{
	while (ms >= 1000)
	{
		usleep(1000 * 1000);
		ms -= 1000;
	};
	if (ms != 0)
		usleep(ms * 1000);
}
#endif

using namespace sl;// 关于雷达
using namespace std;

void print_usage(int argc, const char* argv[])
{
	printf("Usage:\n"
		" For serial channel\n %s --channel --serial <com port> [baudrate]\n"
		" The baudrate used by different models is as follows:\n"
		"  A1(115200),A2M7(256000),A2M8(115200),A2M12(256000),"
		"A3(256000),S1(256000),S2(1000000),S3(1000000)\n"
		" For udp channel\n %s --channel --udp <ipaddr> [port NO.]\n"
		" The T1 default ipaddr is 192.168.11.2,and the port NO.is 8089. Please refer to the datasheet for details.\n"
		, argv[0], argv[0]);
}

bool checkSLAMTECLIDARHealth(ILidarDriver* drv)
{
	sl_result     op_result;
	sl_lidar_response_device_health_t healthinfo;

	op_result = drv->getHealth(healthinfo);
	if (SL_IS_OK(op_result))
	{ // the macro IS_OK is the preperred way to judge whether the operation is succeed.
		printf("SLAMTEC Lidar health status : %d\n", healthinfo.status);
		if (healthinfo.status == SL_LIDAR_STATUS_ERROR)
		{
			fprintf(stderr, "Error, slamtec lidar internal error detected. Please reboot the device to retry.\n");
			// enable the following code if you want slamtec lidar to be reboot by software
			// drv->reset();
			return false;
		}
		else
		{
			return true;
		}

	}
	else
	{
		fprintf(stderr, "Error, cannot retrieve the lidar health code: %x\n", op_result);
		return false;
	}
}

bool ctrl_c_pressed;// 处理 ctrl_c 引起的中断
void ctrlc(int)
{
	ctrl_c_pressed = true;
}

// 宏定义检测范围的xy上下限度， 单位cm。坐标原点即极坐标原点，x正方向是90°到270°，y正方向是0°到180°
# define y_Upper_cm 150
# define y_Lower_cm 50
# define x_Upper_cm 150
# define x_Lower_cm -150

//(新增)measure_coordinate_cm;
struct OrthogonalData// 用于Vrt_coordinate_cm_Array
{
	int x_cm;
	int y_cm;
};

int main(int argc, const char* argv[])
{
	const char* opt_is_channel = NULL;
	const char* opt_channel = NULL;// 存储通信方式:serial or udp
	const char* opt_channel_param_first = NULL;// 存储串口号
	sl_u32         opt_channel_param_second = 0;// 存储波特率
	sl_u32         baudrateArray[2] = { 115200, 256000 };// 波特率数组
	sl_result     op_result;
	int          opt_channel_type = CHANNEL_TYPE_SERIALPORT;// 通信类型默认在此设置为串口

	bool useArgcBaudrate = false;// 判断是否读取了波特率

	IChannel* _channel;// 创建通信通道实例

	printf("Ultra simple LIDAR data grabber for SLAMTEC LIDAR.\n"
		"Version: %s\n", SL_LIDAR_SDK_VERSION);// 打印程序名字和程序版本


	/*——-----------------------------------------检查和读取控制台输入数据————————————————————————------*/

	if (argc > 1)
	{
		opt_is_channel = argv[1];// 一个常量chat指针指向数组第2个（01）argv[0]是此exe文件的名字
	}
	else// 命令行参数不正确
	{
		print_usage(argc, argv);// 打印使用说明并退出
		return -1;
	}

	if (strcmp(opt_is_channel, "--channel") == 0)
	{// 判断argv[1]是否为规定输入
		opt_channel = argv[2]; // 一个常量chat指针指向数组第3个
		if (strcmp(opt_channel, "-s") == 0 || strcmp(opt_channel, "--serial") == 0)// 判断argv[1]是否为规定输入或者串口连接
		{
			// read serial port from the command line... (从命令行读取串口)
			opt_channel_param_first = argv[3];// or set to a fixed value: e.g. "com3"//argv[3]存储着串口号码
			// read baud rate from the command line if specified...(如果指定，从命令行读取波特率…)
			if (argc > 4) opt_channel_param_second = strtoul(argv[4], NULL, 10);// strtoul读取字符串里的数字(十进制)即串口号	
			useArgcBaudrate = true;
		}
		else if (strcmp(opt_channel, "-u") == 0 || strcmp(opt_channel, "--udp") == 0)// 判断通过udp协议链接
		{
			// read ip addr from the command line...
			opt_channel_param_first = argv[3];// or set to a fixed value: e.g. "192.168.11.2"
			if (argc > 4) opt_channel_param_second = strtoul(argv[4], NULL, 10);// e.g. "8089"
			opt_channel_type = CHANNEL_TYPE_UDP;// 通信类型改成udp
		}
		else
		{
			print_usage(argc, argv);
			return -1;
		}
	}
	else
	{
		print_usage(argc, argv);
		return -1;
	}

	if (opt_channel_type == CHANNEL_TYPE_SERIALPORT)
	{
		if (!opt_channel_param_first)
		{
#ifdef _WIN32
			// use default com port
			opt_channel_param_first = "\\\\.\\com3";
#elif __APPLE__
			opt_channel_param_first = "/dev/tty.SLAB_USBtoUART";
#else
			opt_channel_param_first = "/dev/ttyUSB0";
#endif
		}
	}
	/*——-----------------------------------------检查和读取控制台输入数据————————————————————————------*/


   /*——-----------------------------------------创建并连接LIDAR驱动实例————————————————————————------*/

	   // create the driver instance （创建驱动程序实例）
	ILidarDriver* drv = *createLidarDriver();

	if (!drv)
	{
		fprintf(stderr, "insufficent memory, exit\n");
		exit(-2);
	}

	sl_lidar_response_device_info_t devinfo;
	bool connectSuccess = false;// 判断设备是否连接成功，可以运行下一步

	// 根据指定的通信方式（串口或UDP）创建通信通道
	if (opt_channel_type == CHANNEL_TYPE_SERIALPORT)
	{
		if (useArgcBaudrate)
		{
			_channel = (*createSerialPortChannel(opt_channel_param_first, opt_channel_param_second));// 向通信通道实例输入串口号和波特率
			// 尝试连接到LIDAR设备
			if (SL_IS_OK((drv)->connect(_channel)))
			{ // 通过通道连接雷达
				op_result = drv->getDeviceInfo(devinfo);

				if (SL_IS_OK(op_result))
				{
					connectSuccess = true;
				}
				else
				{
					delete drv;
					drv = NULL;
				}
			}
		}
		else
		{
			size_t baudRateArraySize = (sizeof(baudrateArray)) / (sizeof(baudrateArray[0]));
			for (size_t i = 0; i < baudRateArraySize; ++i)
			{
				_channel = (*createSerialPortChannel(opt_channel_param_first, baudrateArray[i]));
				// 尝试连接到LIDAR设备
				if (SL_IS_OK((drv)->connect(_channel)))
				{
					op_result = drv->getDeviceInfo(devinfo);

					if (SL_IS_OK(op_result))
					{
						connectSuccess = true;
						break;
					}
					else
					{
						delete drv;
						drv = NULL;
					}
				}
			}
		}
	}
	else if (opt_channel_type == CHANNEL_TYPE_UDP)
	{
		_channel = *createUdpChannel(opt_channel_param_first, opt_channel_param_second);
		// 尝试连接到LIDAR设备
		if (SL_IS_OK((drv)->connect(_channel)))
		{
			op_result = drv->getDeviceInfo(devinfo);

			if (SL_IS_OK(op_result))
			{
				connectSuccess = true;
			}
			else
			{
				delete drv;
				drv = NULL;
			}
		}
	}


	if (!connectSuccess)
	{ // 连接LIDAR设备失败
		(opt_channel_type == CHANNEL_TYPE_SERIALPORT) ?
			(fprintf(stderr, "Error, cannot bind to the specified serial port %s.\n"
				, opt_channel_param_first)) : (fprintf(stderr, "Error, cannot connect to the specified ip addr %s.\n"
					, opt_channel_param_first));

		goto on_finished;
	}

	// print out the device serial number, firmware and hardware version number..(打印出设备序列号、固件和硬件版本号。)
	printf("SLAMTEC LIDAR S/N: ");
	for (int pos = 0; pos < 16; ++pos)
	{
		printf("%02X", devinfo.serialnum[pos]);
	}

	printf("\n"
		"Firmware Ver: %d.%02d\n"
		"Hardware Rev: %d\n"
		, devinfo.firmware_version >> 8
		, devinfo.firmware_version & 0xFF
		, (int)devinfo.hardware_version);
	/*——-----------------------------------------创建并连接LIDAR驱动实例————————————————————————------*/

	/*——---------------------------------------------检查设备健康状态—---———————————————————————------*/

	   // check health...()
	if (!checkSLAMTECLIDARHealth(drv))
	{
		goto on_finished;
	}
	/*——---------------------------------------------检查设备健康状态—---———————————————————————------*/

	/*——-----------------------------------------------扫描结果并打印—---—————-——————————————————------*/

	signal(SIGINT, ctrlc);//ctel_c的中断

	if (opt_channel_type == CHANNEL_TYPE_SERIALPORT)//串口通信模式下设置马达速度
		drv->setMotorSpeed();

	// start scan...
	drv->startScan(0, 1);//开始扫描(设备预定义的典型模式启动扫描，而不会强制中断任何当前的操作)

	// fetech result and print it out...(读取结果并打印出来)
	//int Number_of_measurements = 1;//扫描次数
	while (1)
	{
		sl_lidar_response_measurement_node_hq_t nodes[8192]; // 创建一个数组用于存储扫描结果
		size_t   count = _countof(nodes);// 获取数组的大小(见预处理)

		op_result = drv->grabScanDataHq(nodes, count);// 获取扫描数据
		/*等待并抓取之前接收到的完整0-360度扫描数据。这个接口返回的抓取扫描数据总是具有以下特征:
		1)抓取数据数组的第一个节点(nodebuffer(O))必须是扫描的第一个样本，即start_bit == 1
		2)所有数据节点都属于一个完整的360度扫描
		3)注意，一次扫描中的角度数据可能不是升序的。您可以使用API ascendscanata来重新排序节点缓冲区。*/

		if (SL_IS_OK(op_result))
		{
			drv->ascendScanData(nodes, count); // 根据扫描中的角度值升序扫描数据

			/*——---------------------------新增-----扫描数据转化为直角坐标—同步摘取符合条件数据---——------*/
			// 定义一个 vector，存储测量数据的直角坐标表示，先排除了0-90 270-360°的数据
			vector<OrthogonalData> Vrt_coordinate_cm_Array;//这个动态数组是变化数据的直角坐标
			for (int pos = 305; pos < 900; ++pos)// 305->90° 900->270° 经验数据
			{ // 遍历范围内的极坐标
				// 先将原始数据处理为极坐标
				int D_cm = (nodes[pos].dist_mm_q2 / 4.0f) / 10;// 计算距离(2的2次方) 单位换算再除以10
				int Ang = (nodes[pos].angle_z_q14 * 90.f) / 16384;//原版

				// 再将测量数据转为直角坐标
				int meas_x_cm = -(D_cm * sin(Ang * M_PI / 180.0));// x = -Y, Y = D * sin()
				int meas_y_cm = -(D_cm * cos(Ang * M_PI / 180.0));// y = -X, X = D * cos()

				// 判断是否为变化数据(符合条件为是)
				if ((meas_x_cm >= x_Lower_cm && meas_x_cm <= x_Upper_cm) && (meas_y_cm >= y_Lower_cm && meas_y_cm <= y_Upper_cm))
				{
					OrthogonalData data;//变化点位的直角坐标
					data.x_cm = meas_x_cm;
					data.y_cm = meas_y_cm;
					Vrt_coordinate_cm_Array.push_back(data);
				}
			}//此处扫描一次 并已经得到所有结果 但是没有简化处理
			cout << "~~~The change data of a scan was obtained successfully~~~" << endl;
			/*——---------------------------新增-----扫描数据转化为直角坐标—---------------——------*/

			/*——---------------------------打印变化变化点位的直角坐标—----------------------——------*/
			/*cout << "Printing Variation coordinate:" << endl;
			for (size_t i = 0; i < Vrt_coordinate_cm_Array.size(); ++i)
			{
				cout << "Vrt_coordinate_cm_Array[" << i << "].x_cm = " << Vrt_coordinate_cm_Array[i].x_cm << "; ";
				cout << "y_cm = " << Vrt_coordinate_cm_Array[i].y_cm << endl;
			}*/
			/*——---------------------------打印变化变化点位的直角坐标—----------------------——------*/

			// 一次扫描后的等待时间
			this_thread::sleep_for(chrono::seconds(1));// 本线程休息1s
			//Sleep(1000);// 单位是ms 1s

			/*——---------------------------计算发送信息—----------------------——------*/
			/*——---------------------------发送信息—master----------------------——------*/
			/*——---------------------------等待确认—----------------------——------*/
			//一次没等到 写进日志 重新发送 ；三次没等到 打印报错 都写进入外部txt文档 跳过
			/*——---------------------------收到确认-进入下一次扫描---------------——------*/

		}
			//Number_of_measurements--;

			if (ctrl_c_pressed)
			{ //ctrl_c中断循环
				break;
			}
		
	}
		/*——-----------------------------------------------扫描结果并打印—---—————-——————————————————------*/

		/*——--------------------------------------------------扫描停止—---—————-—----—————————————————------*/
			//暂时停止的原因只有ctrl_c的中断
		drv->stop();
		delay(200);
		if (opt_channel_type == CHANNEL_TYPE_SERIALPORT)
			drv->setMotorSpeed(0);
		// done！
	/*——--------------------------------------------------扫描停止—---—————-—----—————————————————------*/
	on_finished:
		if (drv)
		{
			delete drv;
			drv = NULL;
		}
		return 0;
}

