#include <iostream>
#include <vector>
#include <iomanip>  // 提供 setw 函数

// 定义结构体
struct NumberCoordinate {
    int b; // 在b行
    int a; // 在a列

    // 自定义比较函数，用于 std::unique() 去重
    bool operator==(const NumberCoordinate& other) const {
        return a == other.a && b == other.b;
    }
};

int main() {
    // 创建结构体数组
    std::vector<NumberCoordinate> coordinates = {
        {1, 32},
        {2, 3},
        {3, 14}
    };

    // 存储结果的 char 变量
    char result[100] = {};  // 初始化为全零，避免未初始化问题
    int index = 0;  // 用于追踪 result 数组的索引位置

    // 遍历结构体数组
    for (const auto& coord : coordinates) {
        // 将 a 和 b 转换为字符串格式，确保两位数，不足补零
        char buffer[10];  // 缓冲区
        std::sprintf(buffer, "%02d%02d", coord.a, coord.b);

        // 将 buffer 中的数据追加到 result 数组中，并添加分隔符 'G'
        std::sprintf(result + index, "%sG", buffer);

        // 更新 result 数组的索引位置
        index += std::strlen(buffer) + 1;  // 加上 'G' 的长度
    }

    // 输出结果
    std::cout << "存储格式为：" << result << std::endl;

    return 0;
}
