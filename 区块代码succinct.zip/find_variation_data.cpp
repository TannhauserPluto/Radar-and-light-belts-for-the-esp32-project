#include <iostream>
#include <vector>
#include <cstdint>

using namespace std;

// 结构体定义
struct ReferenceData {
    double Rfr_angle;   // 使用 double 类型保存角度值，保留小数点后两位
    double Rfr_dist_mm; 
};

// 结构体定义用于存储满足条件的节点数据
struct VariationData {
    double Vrt_angle;   // 使用 double 类型保存角度值，保留小数点后两位
    double Vrt_dist_mm; 
};

int main() {
    // 假设已经有 nodes 和 Reference_Array 数组

    // 定义存储满足条件的数据的向量
    vector<VariationData> Variation_Array;


    // 遍历 Reference_Array
    for (size_t i = 5; i < Reference_Array.size(); ++i) {// 前5个数据忽略
        double ref_angle = Reference_Array[i].Rfr_angle;
        double ref_dist_mm = Reference_Array[i].Rfr_dist_mm;

        bool over = 1;// 1是运行

        // 查找符合条件的 nodes 数据
        while (over){
            //(size_t j = 0; j < nodes.size(); ++j)
            for(size_j = i+299;j<=900;++j){// 从i的前5个开始查，但是j只要305行（304数组）开始,900行以后不要

            double calc_angle = (nodes[j].angle_z_q14 * 90.0) / 16384.0;
            double calc_dist_mm = nodes[j].dist_mm_q2 / 4.0;

            // 检查角度是否在误差范围内（最多相差2）
            if (calc_angle >= ref_angle - 2 && calc_angle <= ref_angle + 2) {
                // 计算误差百分比
                double dist_mm_error = abs(calc_dist_mm - ref_dist_mm) / ref_dist_mm * 100.0;

                // 检查误差是否超过10%
                if (dist_mm_error <= 10.0) {
                    // 将符合条件的数据存入 Variation_Array
                    VariationData data;
                    data.Vrt_angle = calc_angle;
                    data.Vrt_dist_mm = calc_dist_mm;
                    Variation_Array.push_back(data);}
            
                }
                if（calc_angle >= ref_angle + 2{// 太大就不用检测了
                over=0;
                goto Increase_ref_i;
            }
            }

        }
    Increase_ref_i：i+=2；// 直接到外循环，让i加2，再通过循环+1
    }

    // 输出符合条件的 Variation_Array 中的数据
    cout << "Printing Variation_Array:" << endl;
    for (size_t i = 0; i < Variation_Array.size(); ++i) {
        cout << "Variation_Array[" << i << "].Vrt_angle = " << Variation_Array[i].Vrt_angle << "; ";
        cout << "Variation_Array[" << i << "].Vrt_dist_mm = " << Variation_Array[i].Vrt_dist_mm << endl;
    }

    return 0;
}
