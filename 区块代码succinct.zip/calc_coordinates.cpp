#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

struct VariationData {
    double Vrt_angle;  
    double Vrt_dist_mm; 
};

int main() {
    // 假设已经有 Variation_Array 数组

    // 定义变量
    double rltv_boundary_angle;
    int coordinate_ab_cm;
    int coordinate_rltv_cm[Variation_Array.size()]; // 不确定两者一致是否正确

    // 遍历 Variation_Array
    for (size_t i = 0; i < Variation_Array.size(); ++i) {
        double angle = Variation_Array[i].Vrt_angle;
        double dist_mm = Variation_Array[i].Vrt_dist_mm / 10.0; // 距离单位为厘米

        if (angle > 90 && angle < 180) {
            rltv_boundary_angle = angle - 90;
            coordinate_ab_cm = cos(rltv_boundary_angle * M_PI / 180.0) * dist_mm;
            coordinate_rltv_cm[i] = -coordinate_ab_cm;
        } else if (angle >= 180 && angle < 270) {
            rltv_boundary_angle = 270 - angle;
            coordinate_ab_cm = cos(rltv_boundary_angle * M_PI / 180.0) * dist_mm;
            coordinate_rltv_cm[i] = coordinate_ab_cm;
        }

        //输出结果示例（还未写）
    }

    return 0;
}
