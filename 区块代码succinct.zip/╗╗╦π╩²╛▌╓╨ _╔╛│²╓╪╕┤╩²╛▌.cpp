#include <iostream>
#include <cmath>    // 向上取整函数 ceil 所需的头文件
#include <vector>   // 使用 vector 存储新数据
#include <algorithm>    // 使用 std::sort 和 std::unique 函数

// 定义结构体
struct MyStruct
{
    int b;
    int a;

    // 自定义比较函数，用于 std::unique() 去重
    bool operator==(const MyStruct& other) const
    {
        return a == other.a && b == other.b;
    }
};

int main()
{
    // 存储新数据的容器
    std::vector<MyStruct> processed_data = {
        {1, 2},
        {2, 3},
        {3, 4},
        {1, 2},
        {4, 5},
        {2, 3},
        {4,3},
        {3, 3},
        {1, 30},
        {3, 4},{3, 4}
    };

    // 删除重复数据
    std::sort(processed_data.begin(), processed_data.end(),
        [](const MyStruct& lhs, const MyStruct& rhs) {
            if (lhs.a == rhs.a)
            {
                return lhs.b < rhs.b;
            }
            return lhs.a < rhs.a;
        });

    auto last = std::unique(processed_data.begin(), processed_data.end());  // 然后移除相邻的重复元素
    processed_data.erase(last, processed_data.end());  // 最后擦除多余的元素

    // 输出去重后的数据
    std::cout << "去重后的数据：" << std::endl;
    for (const auto& item : processed_data)
    {
        std::cout << "b: " << item.b << ", a: " << item.a << std::endl;
    }

    return 0;
}

